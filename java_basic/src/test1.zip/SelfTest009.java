package test1;

public class SelfTest009 {

	public static void main(String[] args) {
		int i = 1;
		while(i<11) {
			System.out.print(i+" ");
			i++;
		}

	}

}
//[SelfTest009] while
//	1,2,3,4,5,6,7,8,9,10 출력