package test1;

public class SelfTest002 {

	public static void main(String[] args) {
		System.out.println("10" +"+"+ "20");

	}

}
